package com.example.test03intentresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String id, pw, name, address, nic ;
    int age;

    Button btn ; //버튼을 선언한다.
    EditText edt_id , edt_pw , edt_name , edt_age , edt_addr , edt_nic ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //버튼을 사용하기 위해서는 버튼을 실제로 찾는 코드를 작성해야 한다.
        //버튼을 찾는다.
        btn = findViewById(R.id.btn);

        //버튼의 기능을 지정한다.
        //묵시적 , 암시적 Intent 사용해보기
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //DTO 아이디값 찾기
                edt_id = findViewById(R.id.edt_id);
                edt_pw = findViewById(R.id.edt_pw);
                edt_name = findViewById(R.id.edt_name);
                edt_age = findViewById(R.id.edt_age);
                edt_addr = findViewById(R.id.edt_addr);
                edt_nic = findViewById(R.id.edt_nic);

                //editText에 현재 입력되어 있는 값을 가져옴
                //입력받은 text표기 String객체로 Text를 리턴
                id = edt_id.getText().toString();
                pw = edt_id.getText().toString();
                name = edt_name.getText().toString();
                address = edt_addr.getText().toString();
                nic = edt_nic.getText().toString();
                age = Integer.parseInt(edt_age.getText().toString());

                DTO dto = new DTO();
                dto.setId(id);
                dto.setPw(pw);
                dto.setName(name);
                dto.setAge(age);
                dto.setAddress(address);
                dto.setNic(nic);


                //인텐트 설정 : Intent 어떤 값 또는 액션을 지정해놓고 새창을 띄우거나
                //어떤 메세지를 전달하는 목적으로 사용하는 객체.
                Intent intent = new Intent(
                        //intent를 지금위치와 이동할 위치를 지정을하고 초기화.
                        MainActivity.this //this 현재 참조중인 MainActivity를 지정.
                       , SubActivity.class);          //SubActivity로 이동

                //Intent 안에 있는 putExtra 함수를 호출 dto의 보내줄 데이터를 intent에 보관
                intent.putExtra("dto", dto);

                startActivity(intent);            //초기화 완료.

                //Toast.makeText(MainActivity.this , "회원가입이 완료됩니다..", Toast.LENGTH_LONG).show();
            }
        });

    }
}