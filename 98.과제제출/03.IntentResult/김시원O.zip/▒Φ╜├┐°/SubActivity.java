package com.example.test03intentresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        //↑ 디자인 로딩이 완료가 되고나서 위젯을 찾는다.
        TextView tv2 = findViewById(R.id.tv2);
        //MainActivity Intent=> SubActivity
        Intent intent = getIntent(); // 모델
        DTO dto = (DTO) intent.getSerializableExtra("dto");

        tv2.append(dto.getId() + "\r\n" + dto.getPw() + "\r\n" + dto.getName() + "\r\n" + dto.getAddress() + "\r\n" + dto.getNic() + "\r\n" + dto.getAge());//기존내용 + 새로운 글자

    }
}