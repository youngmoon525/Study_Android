package com.example.test03intentresult;

import java.io.Serializable;

public class DTO implements Serializable {
    String id, pw, name, address, nic ;
    int age;


    //intent가 객체를 보낼때는 반드시 Serializable을 해줘야하는 규칙이 있다.
    /* alt + insert*/
    public DTO(String id, String pw, String name, String address, String nic, int age) {
        this.id = id;
        this.pw = pw;
        this.name = name;
        this.address = address;
        this.nic = nic;
        this.age = age;


    }

    public DTO() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
