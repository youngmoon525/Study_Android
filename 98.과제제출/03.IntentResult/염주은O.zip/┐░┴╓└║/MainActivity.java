package com.example.test02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button joinBtn;
    String id, pw, name, addr, nick;
    int age;

    EditText joinId, joinPw, joinName, joinAge, joinAddr, joinNick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        joinId = findViewById(R.id.joinId);
        joinPw = findViewById(R.id.joinPw);
        joinName = findViewById(R.id.joinName);
        joinAge = findViewById(R.id.joinAge);
        joinAddr = findViewById(R.id.joinAddr);
        joinNick = findViewById(R.id.joinNick);
        joinBtn = findViewById(R.id.joinBtn);

        joinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);

                id = joinId.getText().toString();
                pw = joinPw.getText().toString();
                name = joinName.getText().toString();
                age = Integer.parseInt(joinAge.getText().toString());
                addr = joinAddr.getText().toString();
                nick = joinNick.getText().toString();
                JoinDTO dto = new JoinDTO(id, pw, name, addr, nick, age);

                intent.putExtra("dto", dto);
                startActivity(intent);
            }
        });
    }

}