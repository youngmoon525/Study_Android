package com.example.test02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        TextView joinId = findViewById(R.id.joinId);
        TextView joinPw = findViewById(R.id.joinPw);
        TextView joinName = findViewById(R.id.joinName);
        TextView joinAge = findViewById(R.id.joinAge);
        TextView joinAddr = findViewById(R.id.joinAddr);
        TextView joinNick = findViewById(R.id.joinNick);

        Intent intent = getIntent();
        JoinDTO dto = (JoinDTO) intent.getSerializableExtra("dto");

        joinId.setText(dto.getId());
        joinPw.setText(dto.getPw());
        joinName.setText(dto.getName());
        joinAge.setText(dto.getAge()+"");
        joinAddr.setText(dto.getAddr());
        joinNick.setText(dto.getNick());
    }
}