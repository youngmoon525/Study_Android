package com.example.test_06;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        //↑ 디자인 로딩이 완료가 되고나서 위젯을 찾는다.
        TextView tv2 = findViewById(R.id.tv2);
        //MainActivity Intent=> SubActivity
        Intent intent = getIntent(); // 모델
        UserDTO dto =(UserDTO) intent.getSerializableExtra("dto");

        tv2.append(dto.getId() +"\r\n"+ dto.getPw() +"\r\n"+ dto.getName() +"\r\n"+ dto.getAge() +"\r\n"+ dto.getAddress() +"\r\n"+ dto.getNickname());
        //기존내용 + 새로운 글자

    }//onCreate()

}//SubActivity