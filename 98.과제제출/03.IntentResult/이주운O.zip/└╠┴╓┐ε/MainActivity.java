package com.example.test_06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {
    String id, pw, name, address, nickname;
    int age;
    private EditText et_id, et_pw, et_name, et_address, et_nickname, et_age, et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1); //버튼 초기화
        //버튼 기능
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //아이디값 찾아주기
            et_id = findViewById(R.id.id);
            et_pw = findViewById(R.id.pw);
            et_name = findViewById(R.id.name);
            et_age = findViewById(R.id.age);
            et_address = findViewById(R.id.address);
            et_nickname = findViewById(R.id.nickname);

            //입력받은 text표기 String객체로 Text를 리턴
            id = et_id.getText().toString();
            pw = et_pw.getText().toString();
            name = et_name.getText().toString();
            age = Integer.parseInt(et_age.getText().toString());
            address = et_address.getText().toString();
            nickname = et_nickname.getText().toString();

            UserDTO dto = new UserDTO();
            dto.setId(id);
            dto.setPw(pw);
            dto.setName(name);
            dto.setAge(age);
            dto.setAddress(address);
            dto.setNickname(nickname);

            //인텐트 설정하기
            Intent intent = new Intent(MainActivity.this, SubActivity.class);
            //intent를 지금위치와 이동할 위치를 지정을하고 초기화.
            intent.putExtra("dto",dto);
            //Intent 안에 있는 putExtra 함수를 호출 dto의 보내줄 데이터를 intent 넣어둠.
            startActivity(intent);

            }
        });
    }
}