package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        EditText id = findViewById(R.id.id);
        EditText pw = findViewById(R.id.pw);
        EditText name = findViewById(R.id.name);
        EditText age = findViewById(R.id.age);
        EditText ad = findViewById(R.id.ad);
        EditText nick = findViewById(R.id.nick);

        ActivityDTO dto = new ActivityDTO();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this , SubActivity.class);
                dto.setId(id.getText()+"");
                dto.setPw(pw.getText()+"");
                dto.setName(name.getText()+"");
                dto.setAge(Integer.parseInt(age.getText()+""));
                dto.setAd(ad.getText()+"");
                dto.setNick(nick.getText()+"");


                intent.putExtra("dto" ,  dto);



                startActivity(intent);

            }
        });



    }
}