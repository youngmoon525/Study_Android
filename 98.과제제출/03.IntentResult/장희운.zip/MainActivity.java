package com.example.my10_1inetsttest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    Button btn1;
    TestDTO dto = new TestDTO();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText tv1 = findViewById(R.id.editTextTextPersonName);
        EditText tv2 = findViewById(R.id.editTextTextPersonName2);
        EditText tv3 = findViewById(R.id.editTextTextPersonName3);
        EditText tv4 = findViewById(R.id.editTextTextPersonName4);
        EditText tv5 = findViewById(R.id.editTextTextPersonName5);
        EditText tv6 = findViewById(R.id.editTextTextPersonName6);
        btn1 = findViewById(R.id.button);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, subActivity.class);
                dto.setId(tv1.getText()+"");
                dto.setPw(tv2.getText()+"");
                dto.setName(tv3.getText()+"");
                dto.setAge(tv4.getText()+"");
                dto.setAddr(tv5.getText()+"");
                dto.setNickname(tv6.getText()+"");
                intent.putExtra("dto", dto);
                startActivity(intent);
            }
        });
    }
}