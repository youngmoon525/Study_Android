package com.example.my10_1inetsttest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;


public class subActivity extends AppCompatActivity {

    TextView id;
    TextView pw;
    TextView name;
    TextView age;
    TextView addr;
    TextView nickName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        // 디자인 로딩이 완료가 되고나서 위젯을 찾는다.
        id = findViewById(R.id.editTextTextPersonName);
        pw = findViewById(R.id.editTextTextPersonName2);
        name = findViewById(R.id.editTextTextPersonName3);
        age = findViewById(R.id.editTextTextPersonName4);
        addr = findViewById(R.id.editTextTextPersonName5);
        nickName = findViewById(R.id.editTextTextPersonName6);
        //MainActivity Intent => SubActivity
        Intent intent = getIntent(); //모델
        TestDTO dto = (TestDTO) intent.getSerializableExtra("dto");

       id.setText(dto.getId());
       pw.setText(dto.getPw());
       name.setText(dto.getName());
       age.setText(dto.getAge());
       addr.setText(dto.getAddr());
       nickName.setText(dto.getNickname());


    }
}