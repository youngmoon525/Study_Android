package com.example.insertresult;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;



public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        
        TextView tv1 = findViewById(R.id.textView22);
        TextView tv2 = findViewById(R.id.textView23);
        TextView tv3 = findViewById(R.id.textView21);
        TextView tv4 = findViewById(R.id.textView24);
        TextView tv5 = findViewById(R.id.textView20);
        TextView tv6 = findViewById(R.id.textView19);

        Intent intent = getIntent();
        IntentDTO dto = (IntentDTO) intent.getSerializableExtra("dto");
        tv1.setText(dto.id);
        tv2.setText(dto.pw);
        tv3.setText(dto.name);
        tv4.setText(dto.age+"");
        tv5.setText(dto.ad);
        tv6.setText(dto.nick);
    }
}
