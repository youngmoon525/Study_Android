package com.example.insertresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        EditText edt_id = findViewById(R.id.editTextTextPersonName);
        EditText edt_pw = findViewById(R.id.editTextTextPassword);
        EditText edt_name = findViewById(R.id.editTextTextPersonName2);
        EditText edt_age = findViewById(R.id.editTextTextPersonName3);
        EditText edt_ad = findViewById(R.id.editTextTextPersonName4);
        EditText edt_nick = findViewById(R.id.editTextTextPersonName5);




        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                try {
                    String id = edt_id.getText() + "";
                    String pw = edt_pw.getText() + "";
                    String name = edt_name.getText() + "";
                    int age = Integer.parseInt(edt_age.getText() + "");
                    String ad = edt_ad.getText() + "";
                    String nick = edt_nick.getText() + "";

                    IntentDTO dto = new IntentDTO(id, pw, name, age, ad, nick);
                    intent.putExtra("dto", dto);

                    startActivity(intent);
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }
}