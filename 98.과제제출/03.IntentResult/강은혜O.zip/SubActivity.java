package com.example.test02_intentresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        TextView s_id = findViewById(R.id.s_id);
        TextView s_pw = findViewById(R.id.s_pw);
        TextView s_name = findViewById(R.id.s_name);
        TextView s_age = findViewById(R.id.s_age);
        TextView s_addr = findViewById(R.id.s_addr);
        TextView s_nickname = findViewById(R.id.s_nickname);

        Intent intent = getIntent();

        IntentResultDTO dto = (IntentResultDTO) intent.getSerializableExtra("dto");
        s_id.setText(dto.getId());
        s_pw.setText(dto.getPw());
        s_name.setText(dto.getName());
        s_age.setText(dto.getAge()+"");
        s_addr.setText(dto.getAddr());
        s_nickname.setText(dto.getNickname());

    }
}