package com.example.test02_intentresult;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn_join;
    String id;
    String pw;
    String name;
    int age;
    String addr;
    String nickname;

    EditText m_id, m_pw, m_name, m_age, m_addr, m_nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_join = findViewById(R.id.btn_join);
        m_id = findViewById(R.id.m_id);
        m_pw = findViewById(R.id.m_pw);
        m_name = findViewById(R.id.m_name);
        m_age = findViewById(R.id.m_age);
        m_addr = findViewById(R.id.m_addr);
        m_nickname = findViewById(R.id.m_nickname);

        btn_join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               id = m_id.getText().toString();
               pw = m_pw.getText().toString();
               name = m_name.getText().toString();
               age = Integer.parseInt(m_age.getText().toString());
               addr = m_addr.getText().toString();
               nickname = m_nickname.getText().toString();


                Intent intent = new Intent( MainActivity.this , SubActivity.class);
                IntentResultDTO dto = new IntentResultDTO(id, pw, name, age, addr, nickname);
                intent.putExtra("dto", dto);

                startActivity(intent);



            }
        });

    }
}