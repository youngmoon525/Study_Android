package com.example.test3;

import java.io.Serializable;

public class UserDTO implements Serializable {
    String id;
    String pw;
    String name;
    int age;
    String address;
    String nickname;

    public UserDTO() {
    }

    public UserDTO(String id, String pw, String name, int age, String address, String nickname) {
        this.id = id;
        this.pw = pw;
        this.name = name;
        this.age = age;
        this.address = address;
        this.nickname = nickname;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getId() {
        return id;
    }

    public String getPw() {
        return pw;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getAddress() {
        return address;
    }

    public String getNickname() {
        return nickname;
    }



}
