package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    String id,pw,name,nickname,address;
    int age;
    EditText id_e,pw_e,name_e,nickname_e,address_e,age_e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                id_e = (EditText)findViewById(R.id.id);
                pw_e = (EditText)findViewById(R.id.pw);
                name_e = (EditText)findViewById(R.id.name);
                address_e = (EditText)findViewById(R.id.add);
                age_e = (EditText)findViewById(R.id.age);
                nickname_e = (EditText)findViewById(R.id.nickname);

                id = id_e.getText().toString();
                pw = pw_e.getText().toString();
                name = name_e.getText().toString();
                address = address_e.getText().toString();
                age = Integer.parseInt(age_e.getText().toString());
                nickname = nickname_e.getText().toString();

                Intent intent = new Intent(MainActivity.this, sub.class);
                UserDTO dto = new UserDTO(id,pw,name,age,address,nickname);
                intent.putExtra("dto",dto);
                startActivity(intent);
            }
        });
    }
}