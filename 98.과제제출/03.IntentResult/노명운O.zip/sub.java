package com.example.test3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class sub extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        TextView tv2 = findViewById(R.id.textView2);
        TextView tv3 = findViewById(R.id.textView3);
        TextView tv4 = findViewById(R.id.textView4);
        TextView tv5 = findViewById(R.id.textView5);
        TextView tv6 = findViewById(R.id.textView6);
        TextView tv7 = findViewById(R.id.textView7);
        Intent intent = getIntent(); // 모델
        //String test = intent.getStringExtra("dto");
        UserDTO dto = (UserDTO) intent.getSerializableExtra("dto");

        tv2.setText(dto.getId());
        tv3.setText(dto.getPw());
        tv4.setText(dto.getName());
        tv5.setText(dto.getAge()+"");
        tv6.setText(dto.getAddress());
        tv7.setText(dto.getNickname());

    }
}
