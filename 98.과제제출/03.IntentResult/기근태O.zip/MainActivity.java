package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        EditText sid = findViewById(R.id.id);
        EditText spw = findViewById(R.id.pw);
        EditText sname = findViewById(R.id.name);
        EditText sage = findViewById(R.id.age);
        EditText saddr = findViewById(R.id.addr);
        EditText snick = findViewById(R.id.nick);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this , SubActivity.class);
                intent.putExtra("id" , "sid");

                InsertDTO dto = new InsertDTO();
                dto.setId(sid.getText()+"");
                dto.setPw(spw.getText()+"");
                dto.setName(sname.getText()+"");
                dto.setAge(sage.getText()+"");
                dto.setAddr(saddr.getText()+"");
                dto.setNick(snick.getText()+"");
                intent.putExtra("dto" , dto);
                startActivity(intent);
            }
        });
    }
}