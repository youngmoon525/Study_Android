package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        TextView sid = findViewById(R.id.sid);
        TextView spw = findViewById(R.id.spw);
        TextView sname = findViewById(R.id.sname);
        TextView sage = findViewById(R.id.sage);
        TextView saddr = findViewById(R.id.saddr);
        TextView snick = findViewById(R.id.snick);
        Intent intent = getIntent();

        InsertDTO dto = (InsertDTO) intent.getSerializableExtra("dto");

        sid.setText(dto.getId());
        spw.setText(dto.getPw());
        sname.setText(dto.getName());
        sage.setText(dto.getAge());
        saddr.setText(dto.getAddr());
        snick.setText(dto.getNick());





    }
}