package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        TextView tv2 = findViewById(R.id.tv2);

        Intent intent = getIntent();

        LoginDTO dto = (LoginDTO) intent.getSerializableExtra("dto");

        tv2.setText(dto.getId() + dto.getPw()+dto.getName()+dto.getAge()+dto.getAddr()+dto.getNickname());


    }
}