package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.submitbtn);

        EditText id = findViewById(R.id.id);
        EditText pw = findViewById(R.id.pw);
        EditText name = findViewById(R.id.name);
        EditText age = findViewById(R.id.age);
        EditText addr = findViewById(R.id.addr);
        EditText nickname = findViewById(R.id.nickname);



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                LoginDTO dto = new LoginDTO();
                dto.setId(id.getText()+"");
                dto.setPw(pw.getText()+"");

                if(login(dto.getId(), dto.getPw())==1){
                    dto.setName(name.getText()+"");
                    dto.setAge(Integer.parseInt(age.getText()+""));
                    dto.setAddr(addr.getText()+"");
                    dto.setNickname(nickname.getText()+"");

                    intent.putExtra("dto",dto);
                    startActivity(intent);
                }



            }


        });

    }
    private int login(String id, String pw) {
        int succ=0;
        if (id.equals("admin") && pw.equals("1234")){
            Toast.makeText(this,"로그인 되었습니다.",Toast.LENGTH_SHORT).show();
            succ = 1;
        }else{
            Toast.makeText(this,"아이디 또는 비밀번호를 확인해주세요.",Toast.LENGTH_SHORT).show();
        }
        return succ;
    }
}