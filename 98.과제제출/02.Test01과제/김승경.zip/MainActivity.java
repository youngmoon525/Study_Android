package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
ImageView imgv1, imgv2, imgv3, imgv4, imgv5, imgv6;
Button c_btn1, c_btn2;
int index = 3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c_btn1 = findViewById(R.id.c_btn1);
        c_btn2 = findViewById(R.id.c_btn2);
        imgv1 = findViewById(R.id.imgv1);
        imgv2 = findViewById(R.id.imgv2);
        imgv3 = findViewById(R.id.imgv3);
        imgv4 = findViewById(R.id.imgv4);
        imgv5 = findViewById(R.id.imgv5);
        imgv6 = findViewById(R.id.imgv6);

        c_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(index == 1){
                    index = 3;
                }else{
                    index --;
                }
                changePt();
            }
        });

        c_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(index == 1){
                    index = 3;
                }else{
                    index --;
                }
                changePt2();
            }
        });

    }

    public void changePt(){
        imgv1.setVisibility(View.GONE);
        imgv2.setVisibility(View.GONE);
        imgv3.setVisibility(View.GONE);
        if(index == 3){
            imgv3.setVisibility(View.VISIBLE);
        }else if(index == 2){
            imgv2.setVisibility(View.VISIBLE);
        }else if(index == 1){
            imgv1.setVisibility(View.VISIBLE);
        }
    }

    public void changePt2(){
        imgv4.setVisibility(View.GONE);
        imgv5.setVisibility(View.GONE);
        imgv6.setVisibility(View.GONE);
        if(index == 3){
            imgv6.setVisibility(View.VISIBLE);
        }else if(index == 2){
            imgv5.setVisibility(View.VISIBLE);
        }else if(index == 1){
            imgv4.setVisibility(View.VISIBLE);
        }
    }
}