package com.example.test01layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2;
    ImageView img1, img2, img3;
    ImageView img;
    int index = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btn_view);
        btn2 = findViewById(R.id.btn_change);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        img = findViewById(R.id.img);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(index == 3){
                    index = 1;
                    changeImg();
                } else {
                    index ++;
                    changeImg();

                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeImgc();
            }
        });
    }

    public void changeImg(){
        img1.setVisibility(View.GONE);
        img2.setVisibility(View.GONE);
        img3.setVisibility(View.GONE);
        if(index == 1){
            img1.setVisibility(View.VISIBLE);
        }
        else if(index == 2){
            img2.setVisibility(View.VISIBLE);
        }
        else if(index == 3){
            img3.setVisibility(View.VISIBLE);
        }
    }
    public void changeImgc(){
        if(index == 1){
            img.setImageResource(R.drawable.img1);
        }
        else if(index == 2){
            img.setImageResource(R.drawable.img2);
        }
        else if(index == 3){
            img.setImageResource(R.drawable.img3);
        }
    }
}