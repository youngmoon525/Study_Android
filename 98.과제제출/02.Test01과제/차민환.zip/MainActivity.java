package com.example.test01test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imgv1, imgv2, imgv3, scrimgv1, scrimgv2, scrimgv3;
    Button btn1, btn2;
    int index = 3; //현재 보여지는 이미지뷰의 번호라고 생각을함.
    int index2 = 3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        imgv1 = findViewById(R.id.imgv1);
        imgv2 = findViewById(R.id.imgv2);
        imgv3 = findViewById(R.id.imgv3);
        scrimgv1 = findViewById(R.id.scrimgv1);
        scrimgv2 = findViewById(R.id.scrimgv2);
        scrimgv3 = findViewById(R.id.scrimgv3);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index++;
                changeImg();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index2++;
                changeScrImg();
            }
        });
    }

    public void changeImg() {
        imgv1.setVisibility(View.GONE);
        imgv2.setVisibility(View.GONE);
        imgv3.setVisibility(View.GONE);
        if (index == 1 || index == 4) {
            imgv1.setVisibility(View.VISIBLE);
            index = 1;
        } else if (index == 2) {
            imgv2.setVisibility(View.VISIBLE);
            index = 2;
        } else if (index == 3 || index == 0) {
            imgv3.setVisibility(View.VISIBLE);
            index = 3;
        }
    }
    public void changeScrImg() {
        scrimgv1.setVisibility(View.GONE);
        scrimgv2.setVisibility(View.GONE);
        scrimgv3.setVisibility(View.GONE);
        if (index2 == 1 || index2 == 4) {
            scrimgv1.setVisibility(View.VISIBLE);
            index2 = 1;
        } else if (index2 == 2) {
            scrimgv2.setVisibility(View.VISIBLE);
            index2 = 2;
        } else if (index2 == 3 || index2 == 0) {
            scrimgv3.setVisibility(View.VISIBLE);
            index2 = 3;
        }
    }
}