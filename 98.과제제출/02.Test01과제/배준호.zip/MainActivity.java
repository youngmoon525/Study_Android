package com.example.mid_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imgv2,imgv3,imgv4,  imgv5,imgv6,imgv7;
    Button btn1, btn2;
    int index =2;
    int index2 = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.chagebtn);
        btn2 = findViewById(R.id.chagebtn2);

        imgv2 = findViewById(R.id.img2);
        imgv3 = findViewById(R.id.img3);
        imgv4 = findViewById(R.id.img4);

        imgv5 = findViewById(R.id.img5);
        imgv6 = findViewById(R.id.img6);
        imgv7 = findViewById(R.id.img7);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeImg();
                index ++ ;


            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeImg2();
                index2 ++ ;

            }
        });



    }



    private void changeImg() {
        imgv2.setVisibility(View.GONE);
        imgv3.setVisibility(View.GONE);
        imgv4.setVisibility(View.GONE);
        if(index==5){
            index=2;
        }
        if(index == 2){
            imgv2.setVisibility(View.VISIBLE);
        }else if(index == 3){
            imgv3.setVisibility(View.VISIBLE);
        }else if(index == 4){
            imgv4.setVisibility(View.VISIBLE);
        }
    }

    private void changeImg2() {
        imgv5.setVisibility(View.GONE);
        imgv6.setVisibility(View.GONE);
        imgv7.setVisibility(View.GONE);
        if(index2 ==8) {
            index2 = 5;
        }
        if(index2 == 5){
            imgv5.setVisibility(View.VISIBLE);
        }else if(index2 == 6){
            imgv6.setVisibility(View.VISIBLE);
        }else if(index2 == 7){
            imgv7.setVisibility(View.VISIBLE);
        }

    }
}